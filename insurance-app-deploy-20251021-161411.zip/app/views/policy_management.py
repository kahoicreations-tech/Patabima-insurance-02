# views/policy_management.py
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.response import Response
from django.http import HttpResponse
from datetime import datetime, timedelta
import uuid
import json
import random
from ..models import MotorPolicy
from ..serializers import MotorPolicySubmissionSerializer, MotorPolicySerializer

try:
    # Reuse calculation helpers for consistent premium logic
    from .motor_flow import _compute_base_premium_simple, _apply_mandatory_levies
except Exception:
    _compute_base_premium_simple = None
    _apply_mandatory_levies = None


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_policy_quote(request):
    """
    Create a new policy quote with all collected information
    """
    quote_data = request.data
    
    # Generate unique policy reference
    policy_reference = f"PB{datetime.now().strftime('%Y%m%d')}{random.randint(1000, 9999)}"
    
    # Calculate policy details
    base_premium = float(quote_data.get('base_premium', 0))
    
    # Calculate mandatory levies
    training_levy = base_premium * 0.0025  # 0.25%
    pcf_levy = base_premium * 0.0025       # 0.25%
    stamp_duty = 40.0                      # Fixed KSh 40
    
    total_levies = training_levy + pcf_levy + stamp_duty
    total_premium = base_premium + total_levies
    
    policy_quote = {
        'policy_reference': policy_reference,
        'quote_status': 'DRAFT',
        'customer_info': quote_data.get('customer_info', {}),
        'vehicle_info': quote_data.get('vehicle_info', {}),
        'cover_details': {
            'category': quote_data.get('category'),
            'cover_type': quote_data.get('cover_type'),
            'underwriter': quote_data.get('underwriter'),
            'cover_start_date': quote_data.get('cover_start_date'),
            'cover_end_date': (datetime.strptime(quote_data.get('cover_start_date'), '%Y-%m-%d') + timedelta(days=365)).strftime('%Y-%m-%d'),
            'sum_insured': quote_data.get('sum_insured')
        },
        'premium_calculation': {
            'base_premium': base_premium,
            'training_levy': round(training_levy, 2),
            'pcf_levy': round(pcf_levy, 2),
            'stamp_duty': stamp_duty,
            'total_levies': round(total_levies, 2),
            'total_premium': round(total_premium, 2)
        },
        'created_at': datetime.now().isoformat(),
        'valid_until': (datetime.now() + timedelta(days=30)).isoformat()
    }
    
    return Response({
        'success': True,
        'policy_quote': policy_quote
    })


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def finalize_policy(request):
    """
    Finalize policy after successful payment
    """
    policy_reference = request.data.get('policy_reference')
    payment_reference = request.data.get('payment_reference')
    
    if not all([policy_reference, payment_reference]):
        return Response({
            'error': 'policy_reference and payment_reference required'
        }, status=400)
    
    # Generate policy number
    policy_number = f"POL/{datetime.now().year}/{random.randint(100000, 999999)}"
    
    return Response({
        'success': True,
        'policy': {
            'policy_number': policy_number,
            'policy_reference': policy_reference,
            'status': 'ACTIVE',
            'payment_reference': payment_reference,
            'activation_timestamp': datetime.now().isoformat(),
            'certificate_url': f'/api/v1/motor/policy/{policy_number}/certificate',
            'receipt_url': f'/api/v1/motor/policy/{policy_number}/receipt'
        }
    })


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def generate_receipt(request, policy_number):
    """
    Generate payment receipt with insurer branding
    """
    # Mock receipt data
    receipt_data = {
        'receipt_number': f"RCP{datetime.now().strftime('%Y%m%d')}{random.randint(1000, 9999)}",
        'policy_number': policy_number,
        'issue_date': datetime.now().strftime('%Y-%m-%d'),
        'insurer': {
            'name': 'CIC Insurance Group',
            'logo_url': 'https://example.com/cic-logo.png',
            'address': 'CIC Plaza, Mara Road, Upper Hill',
            'phone': '+254 20 2828000'
        },
        'customer': {
            'name': 'John Doe',
            'phone': '254708374149',
            'email': 'john.doe@example.com'
        },
        'vehicle': {
            'registration': 'KDD123A',
            'make': 'Toyota',
            'model': 'Hiace'
        },
        'payment': {
            'method': 'M-PESA',
            'reference': 'OGK12345678',
            'amount': 3540.00,
            'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        },
        'premium_breakdown': {
            'base_premium': 3000.00,
            'training_levy': 7.50,
            'pcf_levy': 7.50,
            'stamp_duty': 40.00,
            'total': 3540.00
        }
    }
    
    return Response({
        'success': True,
        'receipt': receipt_data
    })


# =========================
# Public quotation endpoints (no auth)
# =========================

@api_view(['POST'])
@permission_classes([AllowAny])
def submit_motor_quotation(request):
    """
    Public endpoint to submit a motor quotation from the app without requiring auth.
    Does not persist to DB in this minimal version; returns a normalized quotation payload.
    """
    data = request.data or {}
    # Basic fields we expect
    category = data.get('category') or data.get('category_code')
    cover_type = data.get('cover_type') or data.get('subcategory_code')
    underwriter = data.get('underwriter') or data.get('underwriter_code')
    start_date = data.get('cover_start_date') or data.get('start_date')
    # Compute pricing if helpers available
    pricing = None
    if _compute_base_premium_simple and _apply_mandatory_levies and category and cover_type:
        base = _compute_base_premium_simple(category, cover_type, data)
        pricing = _apply_mandatory_levies(base)
    quote_id = f"PUB-QUO-{datetime.now().strftime('%Y%m%d')}-{random.randint(1000,9999)}"
    payload = {
        'quote_id': quote_id,
        'status': 'SUBMITTED',
        'category': category,
        'cover_type': cover_type,
        'underwriter': underwriter,
        'cover_start_date': start_date,
        'vehicle_info': data.get('vehicle_info') or {
            'registration_number': data.get('registration_number') or data.get('vehicle_registration'),
            'make': data.get('vehicle_make'),
            'model': data.get('vehicle_model'),
            'year': data.get('vehicle_year') or data.get('year_of_manufacture'),
        },
        'customer_info': data.get('customer_info') or {
            'name': data.get('customer_name'),
            'phone': data.get('phone') or data.get('phone_number'),
            'email': data.get('email'),
        },
        'submitted_at': datetime.now().isoformat(),
    }
    if pricing:
        payload['premium_breakdown'] = pricing
    return Response({ 'success': True, 'quotation': payload })


@api_view(['GET'])
@permission_classes([AllowAny])
def get_public_quotations(request):
    """
    Public endpoint to retrieve submitted quotations (stateless demo).
    Returns an empty list or a small mock when "demo=true" is provided.
    Optional filter: phone or phone_number
    """
    demo = str(request.GET.get('demo', '')).lower() == 'true'
    phone = request.GET.get('phone') or request.GET.get('phone_number')
    if not demo:
        return Response({ 'results': [], 'count': 0 })
    sample = [
        {
            'quote_id': 'PUB-QUO-EXAMPLE-1234',
            'status': 'SUBMITTED',
            'category': 'PRIVATE',
            'cover_type': 'THIRD_PARTY',
            'underwriter': 'CIC',
            'cover_start_date': datetime.now().strftime('%Y-%m-%d'),
            'customer_info': { 'name': 'John Demo', 'phone': phone or '254700000001' },
            'premium_breakdown': { 'base_premium': 3500, 'training_levy': 8.75, 'pcf_levy': 8.75, 'stamp_duty': 40.0, 'total_levies': 57.5, 'total_premium': 3557.5 },
        }
    ]
    return Response({ 'results': sample, 'count': len(sample) })


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_motor_policy(request):
    """
    Create a new motor insurance policy from Motor 2 flow.
    
    Expected payload from frontend:
    {
        "quoteId": "QUOTE-1234567890",
        "clientDetails": {...},
        "vehicleDetails": {...},
        "productDetails": {...},
        "underwriterDetails": {...} or null,
        "premiumBreakdown": {...},
        "paymentDetails": {...},
        "addons": [],
        "documents": []
    }
    
    Returns:
    {
        "success": true,
        "policyNumber": "POL-2024-123456",
        "policyId": "uuid",
        "pdfUrl": null,
        "message": "Policy created successfully"
    }
    """
    # Debug: Print incoming data to see what frontend sends
    print("\n" + "="*80)
    print("MOTOR2 POLICY CREATION - Incoming Request Data:")
    print("="*80)
    import json
    print(json.dumps(request.data, indent=2, default=str))
    print("="*80 + "\n")
    
    # Validate incoming data
    serializer = MotorPolicySubmissionSerializer(data=request.data)
    
    if not serializer.is_valid():
        print("\n" + "="*80)
        print("VALIDATION ERRORS:")
        print(json.dumps(serializer.errors, indent=2, default=str))
        print("="*80 + "\n")
        return Response({
            'success': False,
            'error': 'Validation error',
            'details': serializer.errors
        }, status=400)
    
    validated_data = serializer.validated_data
    
    try:
        # Create new policy instance
        policy = MotorPolicy()
        
        # Generate unique policy number
        policy.policy_number = policy.generate_policy_number()
        
        # Set user (if authenticated)
        policy.user = request.user
        
        # Extract agent code if available from user profile
        if hasattr(request.user, 'agent_code'):
            policy.agent_code = request.user.agent_code
        
        # Set quote ID
        policy.quote_id = validated_data.get('quoteId') or f"QUOTE-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        # Store all the JSON fields
        policy.client_details = validated_data['clientDetails']
        policy.vehicle_details = validated_data['vehicleDetails']
        policy.product_details = validated_data['productDetails']
        policy.underwriter_details = validated_data.get('underwriterDetails')
        policy.premium_breakdown = validated_data['premiumBreakdown']
        policy.payment_details = validated_data['paymentDetails']
        policy.addons = validated_data.get('addons', [])
        policy.documents = validated_data.get('documents', [])
        
        # Extract cover dates if available
        if 'coverStartDate' in validated_data['vehicleDetails']:
            try:
                policy.cover_start_date = datetime.strptime(
                    validated_data['vehicleDetails']['coverStartDate'], 
                    '%Y-%m-%d'
                ).date()
            except (ValueError, TypeError):
                pass
        
        # Set status based on payment method
        payment_method = validated_data['paymentDetails'].get('method', '').lower()
        if payment_method in ['cash', 'mpesa', 'card']:
            # For now, set to PENDING_PAYMENT (will be updated after payment confirmation)
            policy.status = 'PENDING_PAYMENT'
        else:
            policy.status = 'DRAFT'
        
        # Save the policy
        policy.save()
        
        # Prepare response
        response_data = {
            'success': True,
            'policyNumber': policy.policy_number,
            'policyId': str(policy.id),
            'pdfUrl': policy.policy_document_url,  # Will be null initially
            'message': 'Policy created successfully',
            'status': policy.status,
            'submittedAt': policy.submitted_at.isoformat()
        }
        
        return Response(response_data, status=201)
        
    except Exception as e:
        # Log the error (in production, use proper logging)
        print(f"Error creating motor policy: {str(e)}")
        
        return Response({
            'success': False,
            'error': 'Failed to create policy',
            'details': str(e)
        }, status=500)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_motor_policy(request, policy_number):
    """
    Retrieve a specific motor policy by policy number
    """
    try:
        policy = MotorPolicy.objects.get(
            policy_number=policy_number,
            user=request.user
        )
        
        serializer = MotorPolicySerializer(policy)
        
        return Response({
            'success': True,
            'policy': serializer.data
        })
        
    except MotorPolicy.DoesNotExist:
        return Response({
            'success': False,
            'error': 'Policy not found'
        }, status=404)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def list_motor_policies(request):
    """
    List all motor policies for the authenticated user
    """
    policies = MotorPolicy.objects.filter(user=request.user)
    
    # Optional filtering by status
    status = request.GET.get('status')
    if status:
        policies = policies.filter(status=status.upper())
    
    serializer = MotorPolicySerializer(policies, many=True)
    data = serializer.data
    # Non-breaking alias for simpler consumers
    return Response({
        'success': True,
        'count': len(data),
        'policies': data,
        'items': data  # alias
    })


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_upcoming_renewals(request):
    """
    Get Motor 2 policies eligible for renewal (90 days before to 7 days after expiry).
    Uses MotorPolicy.is_renewable computed property.
    """
    from django.utils import timezone
    from datetime import timedelta
    
    today = timezone.now().date()
    renewal_window_start = today - timedelta(days=7)   # 7 days past expiry
    renewal_window_end = today + timedelta(days=90)    # 90 days before expiry
    
    policies = MotorPolicy.objects.filter(
        user=request.user,
        status='ACTIVE',
        cover_end_date__range=[renewal_window_start, renewal_window_end]
    ).order_by('cover_end_date')
    
    renewals = []
    for policy in policies:
        # Use computed property to verify renewability
        if not policy.is_renewable:
            continue
            
        if policy.cover_end_date:
            days_until_expiry = policy.days_until_expiry or 0
            urgency = policy.renewal_urgency
            
            # Map urgency to badge color and status text
            urgency_map = {
                'OVERDUE': {'status': 'Overdue', 'badge_color': '#DC2626'},  # red
                'URGENT': {'status': 'Due Soon', 'badge_color': '#F59E0B'},  # orange
                'STANDARD': {'status': 'Upcoming', 'badge_color': '#3B82F6'},  # blue
                'EARLY_BIRD': {'status': 'Early Renewal', 'badge_color': '#10B981'},  # green
            }
            
            urgency_info = urgency_map.get(urgency, {'status': 'Upcoming', 'badge_color': '#3B82F6'})
            
            renewals.append({
                'id': str(policy.id),
                'policyNo': policy.policy_number,
                'vehicleReg': (policy.vehicle_details.get('registration') or policy.vehicle_details.get('registration_number') or 'N/A'),
                'vehicleMake': policy.vehicle_details.get('make', 'N/A'),
                'vehicleModel': policy.vehicle_details.get('model', 'N/A'),
                'clientName': policy.client_details.get('fullName', 'N/A'),
                'dueDate': policy.cover_end_date.isoformat(),
                'daysLeft': max(0, days_until_expiry),
                'status': urgency_info['status'],
                'urgency': urgency,
                'badgeColor': urgency_info['badge_color'],
                'category': policy.product_details.get('category', 'MOTOR'),
                'coverType': policy.product_details.get('coverType') or policy.product_details.get('subcategory', 'UNKNOWN'),
                'currentPremium': (policy.premium_breakdown.get('total_premium') or policy.premium_breakdown.get('total_amount') or 0),
                'underwriter': policy.underwriter_details.get('name', 'N/A') if policy.underwriter_details else 'N/A'
            })
    
    return Response({
        'success': True,
        'count': len(renewals),
        'renewals': renewals
    })


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_upcoming_extensions(request):
    """
    Get Motor 2 policies eligible for extension.
    Uses ExtendiblePricing model to determine eligibility (admin-configured).
    """
    from django.utils import timezone
    from ..models import MotorSubcategory, ExtendiblePricing
    
    today = timezone.now().date()
    
    # Get EXPIRED policies (not active - they should renew instead)
    expired_policies = MotorPolicy.objects.filter(
        user=request.user,
        status='EXPIRED',
        cover_end_date__isnull=False
    ).order_by('cover_end_date')
    
    extensions = []
    for policy in expired_policies:
        # Use computed property to check if extendable
        if not policy.is_extendable:
            continue
        
        # Get ExtendiblePricing config for this policy
        subcategory_code = policy.product_details.get('subcategory_code') or \
                          policy.product_details.get('subcategory', {}).get('code')
        
        if not subcategory_code:
            continue
        
        try:
            subcategory = MotorSubcategory.objects.get(subcategory_code=subcategory_code)
            underwriter_id = policy.underwriter_details.get('id') if policy.underwriter_details else None
            
            extendible_pricing = ExtendiblePricing.objects.get(
                subcategory=subcategory,
                underwriter_id=underwriter_id
            )
        except (MotorSubcategory.DoesNotExist, ExtendiblePricing.DoesNotExist):
            continue  # Skip if no ExtendiblePricing config
        
        # Calculate extension details
        days_since_expiry = (today - policy.cover_end_date).days
        grace_remaining = extendible_pricing.extension_deadline_days - days_since_expiry
        
        # Calculate late fee based on days since expiry
        late_fee_percentage = float(extendible_pricing.penalty_for_late_extension)
        
        # Determine extension status
        if grace_remaining <= 7:
            extension_status = 'Grace Ending Soon'
            badge_color = '#DC2626'  # red
        elif days_since_expiry > 0:
            extension_status = 'Late Extension'
            badge_color = '#F59E0B'  # orange
        else:
            extension_status = 'Extension Available'
            badge_color = '#10B981'  # green
        
        extensions.append({
            'id': str(policy.id),
            'policyNo': policy.policy_number,
            'vehicleReg': (policy.vehicle_details.get('registration') or policy.vehicle_details.get('registration_number') or 'N/A'),
            'vehicleMake': policy.vehicle_details.get('make', 'N/A'),
            'vehicleModel': policy.vehicle_details.get('model', 'N/A'),
            'clientName': policy.client_details.get('fullName', 'N/A'),
            'expiredDate': policy.cover_end_date.isoformat(),
            'daysSinceExpiry': days_since_expiry,
            'graceRemainingDays': grace_remaining,
            'graceEndDate': policy.extension_grace_end.isoformat() if policy.extension_grace_end else None,
            'status': extension_status,
            'badgeColor': badge_color,
            'balanceAmount': float(extendible_pricing.balance_amount),
            'lateFeePercentage': late_fee_percentage,
            'allowPartialExtension': extendible_pricing.allow_partial_extension,
            'extensionPeriod': f"{extendible_pricing.initial_period_days} days initial coverage",
            'reason': f'Grace period expires in {grace_remaining} days',
            'category': policy.product_details.get('category', 'MOTOR'),
            'coverType': policy.product_details.get('coverType') or policy.product_details.get('subcategory', 'UNKNOWN'),
            'currentPremium': (policy.premium_breakdown.get('total_premium') or policy.premium_breakdown.get('total_amount') or 0)
        })
    
    return Response({
        'success': True,
        'count': len(extensions),
        'extensions': extensions
    })


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def check_renewal_eligibility(request, policy_number):
    """
    Check if a policy is eligible for renewal
    """
    from django.utils import timezone
    from datetime import timedelta
    
    try:
        policy = MotorPolicy.objects.get(
            policy_number=policy_number,
            user=request.user
        )
        
        today = timezone.now().date()
        
        # Check basic eligibility
        is_active = policy.status == 'ACTIVE'
        has_end_date = policy.cover_end_date is not None
        
        if not has_end_date:
            return Response({
                'eligible': False,
                'reason': 'Policy does not have an end date'
            })
        
        days_until_expiry = (policy.cover_end_date - today).days
        
        # Renewal window: 30 days before to 7 days after expiry
        in_renewal_window = -7 <= days_until_expiry <= 30
        
        # Determine renewal type
        if days_until_expiry < 0:
            renewal_type = 'late'
        elif days_until_expiry <= 7:
            renewal_type = 'urgent'
        else:
            renewal_type = 'standard'
        
        eligible = is_active and in_renewal_window
        
        return Response({
            'eligible': eligible,
            'daysUntilExpiry': days_until_expiry,
            'renewalType': renewal_type,
            'currentStatus': policy.status,
            'expiryDate': policy.cover_end_date.isoformat() if policy.cover_end_date else None,
            'reason': None if eligible else 'Policy is not in renewal window or not active'
        })
        
    except MotorPolicy.DoesNotExist:
        return Response({
            'eligible': False,
            'reason': 'Policy not found'
        }, status=404)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def check_extension_eligibility(request, policy_number):
    """
    Check if a policy is eligible for extension (extendible products only)
    """
    from django.utils import timezone
    from datetime import timedelta
    
    try:
        policy = MotorPolicy.objects.get(
            policy_number=policy_number,
            user=request.user
        )
        
        # Check if product is extendible
        is_extendible = policy.product_details.get('is_extendible', False)
        
        if not is_extendible:
            return Response({
                'eligible': False,
                'reason': 'This product is not extendible'
            })
        
        # Check policy status
        is_active = policy.status == 'ACTIVE'
        
        if not is_active:
            return Response({
                'eligible': False,
                'reason': 'Policy is not active'
            })
        
        # Check if already extended
        from ..models import PolicyExtension
        try:
            extension_record = PolicyExtension.objects.get(policy_number=policy_number)
            if extension_record.extension_status == 'extended':
                return Response({
                    'eligible': False,
                    'reason': 'Policy has already been extended'
                })
        except PolicyExtension.DoesNotExist:
            pass
        
        today = timezone.now().date()
        grace_period = today + timedelta(days=30)  # 30-day grace period
        
        # Check if within extension window
        in_extension_window = policy.cover_end_date and policy.cover_end_date <= grace_period
        
        return Response({
            'eligible': in_extension_window,
            'expiryDate': policy.cover_end_date.isoformat() if policy.cover_end_date else None,
            'gracePeriodEnd': grace_period.isoformat(),
            'reason': None if in_extension_window else 'Policy is not within extension window'
        })
        
    except MotorPolicy.DoesNotExist:
        return Response({
            'eligible': False,
            'reason': 'Policy not found'
        }, status=404)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def renew_motor_policy(request, policy_number):
    """
    Renew a Motor 2 policy with updated information and pricing
    """
    try:
        original_policy = MotorPolicy.objects.get(
            policy_number=policy_number,
            user=request.user
        )
        
        # Validate renewal eligibility first
        renewal_check = check_renewal_eligibility(request, policy_number)
        if not renewal_check.data.get('eligible'):
            return Response({
                'success': False,
                'error': 'Policy not eligible for renewal',
                'details': renewal_check.data
            }, status=400)
        
        # Get updated data from request
        updated_data = request.data
        
        # Create new policy as renewal
        renewed_policy = MotorPolicy()
        renewed_policy.policy_number = renewed_policy.generate_policy_number()
        renewed_policy.user = request.user
        renewed_policy.agent_code = original_policy.agent_code
        
        # Mark as renewal
        renewed_policy.is_renewal = True
        renewed_policy.original_policy_id = original_policy.id
        renewed_policy.renewal_count = (original_policy.renewal_count or 0) + 1
        
        # Update client details with any changes
        renewed_policy.client_details = {
            **original_policy.client_details,
            **updated_data.get('clientDetails', {})
        }
        
        # Update vehicle details with any changes
        renewed_policy.vehicle_details = {
            **original_policy.vehicle_details,
            **updated_data.get('vehicleDetails', {})
        }
        
        # Keep product details (can be updated if needed)
        renewed_policy.product_details = {
            **original_policy.product_details,
            **updated_data.get('productDetails', {})
        }
        
        # Update underwriter if changed
        renewed_policy.underwriter_details = updated_data.get('underwriterDetails') or original_policy.underwriter_details
        
        # Recalculate premium if provided, otherwise use original
        renewed_policy.premium_breakdown = updated_data.get('premiumBreakdown') or original_policy.premium_breakdown
        
        # Set payment details
        renewed_policy.payment_details = updated_data.get('paymentDetails', {})
        
        # Set new cover dates
        from datetime import datetime, timedelta
        start_date = datetime.strptime(updated_data.get('coverStartDate', datetime.now().strftime('%Y-%m-%d')), '%Y-%m-%d').date()
        end_date = start_date + timedelta(days=365)
        
        renewed_policy.cover_start_date = start_date
        renewed_policy.cover_end_date = end_date
        
        # Set status
        renewed_policy.status = 'PENDING_PAYMENT'
        
        # Copy addons and documents
        renewed_policy.addons = updated_data.get('addons', original_policy.addons)
        renewed_policy.documents = updated_data.get('documents', original_policy.documents)
        
        # Save the renewed policy
        renewed_policy.save()
        
        # Update original policy status
        original_policy.status = 'EXPIRED'
        original_policy.save()
        
        return Response({
            'success': True,
            'renewedPolicyNumber': renewed_policy.policy_number,
            'renewedPolicyId': str(renewed_policy.id),
            'originalPolicyNumber': original_policy.policy_number,
            'message': 'Policy renewed successfully'
        }, status=201)
        
    except MotorPolicy.DoesNotExist:
        return Response({
            'success': False,
            'error': 'Original policy not found'
        }, status=404)
    except Exception as e:
        return Response({
            'success': False,
            'error': 'Failed to renew policy',
            'details': str(e)
        }, status=500)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def extend_motor_policy(request, policy_number):
    """
    Extend a Motor 2 policy using ExtendiblePricing configuration.
    Only works for policies with admin-configured ExtendiblePricing.
    """
    from django.utils import timezone
    from datetime import timedelta
    from ..models import MotorSubcategory, ExtendiblePricing
    
    try:
        policy = MotorPolicy.objects.get(
            policy_number=policy_number,
            user=request.user
        )
        
        # Validate extension eligibility using computed property
        if not policy.is_extendable:
            return Response({
                'success': False,
                'error': 'Policy not eligible for extension',
                'reason': 'Policy must be expired and have ExtendiblePricing configured'
            }, status=400)
        
        # Get ExtendiblePricing config
        subcategory_code = policy.product_details.get('subcategory_code') or \
                          policy.product_details.get('subcategory', {}).get('code')
        
        if not subcategory_code:
            return Response({
                'success': False,
                'error': 'Cannot determine policy subcategory'
            }, status=400)
        
        try:
            subcategory = MotorSubcategory.objects.get(subcategory_code=subcategory_code)
            underwriter_id = policy.underwriter_details.get('id') if policy.underwriter_details else None
            
            extendible_pricing = ExtendiblePricing.objects.get(
                subcategory=subcategory,
                underwriter_id=underwriter_id
            )
        except (MotorSubcategory.DoesNotExist, ExtendiblePricing.DoesNotExist):
            return Response({
                'success': False,
                'error': 'No extension configuration found for this policy'
            }, status=400)
        
        # Get extension parameters
        months_to_extend = request.data.get('months', 11)  # Default full balance period
        payment_details = request.data.get('paymentDetails', {})
        
        # Calculate extension amount
        today = timezone.now().date()
        days_since_expiry = (today - policy.cover_end_date).days
        
        # Prorated amount based on balance
        if extendible_pricing.allow_partial_extension:
            # Calculate prorated amount for requested months
            days_to_extend = months_to_extend * 30
            prorated_amount = (float(extendible_pricing.balance_amount) / 365) * days_to_extend
        else:
            # Full balance amount
            prorated_amount = float(extendible_pricing.balance_amount)
        
        # Apply late fee based on days since expiry
        late_fee_percentage = float(extendible_pricing.penalty_for_late_extension)
        late_fee = prorated_amount * (late_fee_percentage / 100)
        
        # Calculate mandatory levies
        base_with_late_fee = prorated_amount + late_fee
        itl = base_with_late_fee * 0.0025  # 0.25%
        pcf = base_with_late_fee * 0.0025  # 0.25%
        stamp_duty = 40.00
        
        total_amount = base_with_late_fee + itl + pcf + stamp_duty
        
        # Calculate new expiry date
        if extendible_pricing.allow_partial_extension:
            new_expiry = policy.cover_end_date + timedelta(days=months_to_extend * 30)
        else:
            # Full year extension
            new_expiry = policy.cover_end_date + timedelta(days=365)
        
        # Create extension record (response payload for frontend)
        extension_data = {
            'policyNumber': policy_number,
            'extensionQuote': {
                'prorated_amount': round(prorated_amount, 2),
                'late_fee': round(late_fee, 2),
                'late_fee_percentage': late_fee_percentage,
                'days_since_expiry': days_since_expiry,
                'itl': round(itl, 2),
                'pcf': round(pcf, 2),
                'stamp_duty': stamp_duty,
                'total_amount': round(total_amount, 2)
            },
            'currentExpiryDate': policy.cover_end_date.isoformat(),
            'newExpiryDate': new_expiry.isoformat(),
            'extensionPeriodDays': (new_expiry - policy.cover_end_date).days,
            'graceRemainingDays': extendible_pricing.extension_deadline_days - days_since_expiry,
            'message': 'Extension quote generated. Proceed to payment to activate extension.'
        }
        
        # Store extension data in policy for payment processing
        if not policy.product_details.get('pending_extension'):
            policy.product_details['pending_extension'] = extension_data
            policy.save()
        
        return Response({
            'success': True,
            **extension_data
        }, status=200)
        
    except MotorPolicy.DoesNotExist:
        return Response({
            'success': False,
            'error': 'Policy not found'
        }, status=404)
    except Exception as e:
        import traceback
        print(f"Extension error: {traceback.format_exc()}")
        return Response({
            'success': False,
            'error': 'Failed to generate extension quote',
            'details': str(e)
        }, status=500)
