# views/payment_gateway.py
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
import random
import string
from datetime import datetime
import time


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def initiate_mpesa_payment(request):
    """
    Simulate M-PESA STK Push payment initiation
    """
    phone_number = request.data.get('phone_number')
    amount = request.data.get('amount')
    policy_reference = request.data.get('policy_reference')
    account_reference = request.data.get('account_reference', policy_reference)
    
    if not all([phone_number, amount, policy_reference]):
        return Response({
            'error': 'phone_number, amount, and policy_reference are required'
        }, status=400)
    
    # Validate phone number format
    if not phone_number.startswith('254') or len(phone_number) != 12:
        return Response({
            'error': 'Invalid phone number format. Use 254XXXXXXXXX'
        }, status=400)
    
    # Validate amount
    try:
        amount_float = float(amount)
        if amount_float < 1:
            return Response({'error': 'Amount must be greater than 0'}, status=400)
    except ValueError:
        return Response({'error': 'Invalid amount format'}, status=400)
    
    # Generate transaction reference
    checkout_request_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=15))
    merchant_request_id = ''.join(random.choices(string.digits, k=10))
    
    # Simulate STK push
    return Response({
        'success': True,
        'payment': {
            'checkout_request_id': checkout_request_id,
            'merchant_request_id': merchant_request_id,
            'response_code': '0',
            'response_description': 'Success. Request accepted for processing',
            'customer_message': 'Success. Request accepted for processing',
            'phone_number': phone_number,
            'amount': amount_float,
            'account_reference': account_reference,
            'transaction_desc': f'PataBima Insurance Payment - {policy_reference}',
            'timestamp': datetime.now().isoformat(),
            'status': 'PENDING',
            'provider': 'MPESA_SIMULATION'
        }
    })


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def check_mpesa_payment_status(request):
    """
    Check M-PESA payment status
    """
    checkout_request_id = request.data.get('checkout_request_id')
    
    if not checkout_request_id:
        return Response({'error': 'checkout_request_id required'}, status=400)
    
    # Simulate payment processing delay
    time.sleep(1)
    
    # Randomly simulate success/failure for testing
    payment_outcomes = [
        {
            'result_code': '0',
            'result_desc': 'The service request is processed successfully.',
            'status': 'COMPLETED',
            'mpesa_receipt_number': f'OGK{random.randint(10000000, 99999999)}',
            'transaction_date': datetime.now().strftime('%Y%m%d%H%M%S'),
            'phone_number': '254708374149',
            'amount': 3500.00
        },
        {
            'result_code': '1032',
            'result_desc': 'Request cancelled by user',
            'status': 'CANCELLED',
            'mpesa_receipt_number': None,
            'transaction_date': None,
            'phone_number': '254708374149',
            'amount': 3500.00
        },
        {
            'result_code': '1',
            'result_desc': 'Insufficient funds',
            'status': 'FAILED',
            'mpesa_receipt_number': None,
            'transaction_date': None,
            'phone_number': '254708374149',
            'amount': 3500.00
        }
    ]
    
    # 80% success rate for simulation
    outcome = random.choices(
        payment_outcomes,
        weights=[80, 15, 5],  # 80% success, 15% cancelled, 5% failed
        k=1
    )[0]
    
    return Response({
        'success': True,
        'payment_status': {
            'checkout_request_id': checkout_request_id,
            **outcome,
            'status_check_timestamp': datetime.now().isoformat(),
            'provider': 'MPESA_SIMULATION'
        }
    })


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def initiate_dpo_payment(request):
    """
    Simulate DPO Pay payment initiation
    """
    amount = request.data.get('amount')
    policy_reference = request.data.get('policy_reference')
    customer_email = request.data.get('customer_email')
    customer_phone = request.data.get('customer_phone')
    
    if not all([amount, policy_reference, customer_email]):
        return Response({
            'error': 'amount, policy_reference, and customer_email are required'
        }, status=400)
    
    # Generate DPO transaction token
    transaction_token = ''.join(random.choices(string.ascii_uppercase + string.digits, k=20))
    
    return Response({
        'success': True,
        'payment': {
            'transaction_token': transaction_token,
            'payment_url': f'https://secure.3gdirectpay.com/payv2.php?ID={transaction_token}',
            'amount': float(amount),
            'currency': 'KES',
            'reference': policy_reference,
            'customer_email': customer_email,
            'customer_phone': customer_phone,
            'description': f'PataBima Insurance Payment - {policy_reference}',
            'timestamp': datetime.now().isoformat(),
            'status': 'PENDING',
            'provider': 'DPO_SIMULATION'
        }
    })


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def process_payment_callback(request):
    """
    Handle payment gateway callbacks (M-PESA, DPO)
    """
    provider = request.data.get('provider', '').upper()
    
    if provider == 'MPESA':
        # Process M-PESA callback
        return Response({
            'success': True,
            'message': 'M-PESA callback processed',
            'result_code': '0',
            'result_desc': 'Callback processed successfully'
        })
    elif provider == 'DPO':
        # Process DPO callback
        return Response({
            'success': True,
            'message': 'DPO callback processed',
            'transaction_status': 'COMPLETED'
        })
    else:
        return Response({
            'error': 'Unknown payment provider'
        }, status=400)