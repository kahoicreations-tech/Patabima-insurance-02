from django.urls import path, include
from rest_framework import routers
from rest_framework_simplejwt.views import TokenRefreshView

# Import auth-related viewsets from a dedicated module to avoid collisions
from .auth_views import LoginViewSet, UserViewset
from .commissions_views import CommissionsViewset
from .views_docs import PresignUploadView, SubmitExtractionView, JobStatusView, JobResultView, CallbackView, ApplyResultView
from .views.claims import (
	ClaimsPresignView,
	ClaimsSubmitView,
	ClaimsListView,
	ClaimsDetailView,
)
from .manual_quote_views import AgentManualQuoteViewSet, AdminManualQuoteViewSet
from .campaign_views import PublicCampaignViewSet, AdminCampaignViewSet

router = routers.DefaultRouter(trailing_slash=False)

router.register('auth', LoginViewSet, basename='auth')
router.register('user', UserViewset, basename='user')
router.register('commissions', CommissionsViewset, basename='commissions')
# Register manual quote endpoints
router.register('manual_quotes', AgentManualQuoteViewSet, basename='manual-quotes')
router.register('admin/manual_quotes', AdminManualQuoteViewSet, basename='admin-manual-quotes')
# Register campaign endpoints
router.register('campaigns', PublicCampaignViewSet, basename='campaign')
router.register('admin/campaigns', AdminCampaignViewSet, basename='admin-campaign')

urlpatterns = [
	# Document processing endpoints (public_app scope)
	path('docs/presign', PresignUploadView.as_view()),
	path('docs/submit', SubmitExtractionView.as_view()),
	path('docs/status/<uuid:job_id>', JobStatusView.as_view()),
	path('docs/result/<uuid:job_id>', JobResultView.as_view()),
	path('docs/apply/<uuid:job_id>', ApplyResultView.as_view()),
	path('docs/callback', CallbackView.as_view()),
    # Claims endpoints
    path('claims/presign', ClaimsPresignView.as_view()),
    path('claims/submit', ClaimsSubmitView.as_view()),
    path('claims', ClaimsListView.as_view()),
    path('claims/<uuid:claim_id>', ClaimsDetailView.as_view()),
    # Auth token refresh endpoint for mobile client
    path('auth/token/refresh', TokenRefreshView.as_view()),
]

urlpatterns += router.urls
