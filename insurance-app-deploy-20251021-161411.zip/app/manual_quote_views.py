from rest_framework import viewsets, mixins, status
from rest_framework.response import Response
from rest_framework.decorators import action
from django.utils import timezone

from . import models, serializers
from .permissions_manual_quotes import IsAgentUser, IsStaffOrAdmin


class AgentManualQuoteViewSet(mixins.CreateModelMixin,
                              mixins.ListModelMixin,
                              mixins.RetrieveModelMixin,
                              viewsets.GenericViewSet):
    """Agent endpoints: create and list own manual quotes."""
    serializer_class = serializers.ManualQuoteSerializer
    permission_classes = [IsAgentUser]
    lookup_field = 'reference'

    def get_queryset(self):
        return models.ManualQuote.objects.filter(agent=self.request.user)

    def get_serializer_class(self):
        if self.action == 'create':
            return serializers.ManualQuoteCreateSerializer
        return serializers.ManualQuoteSerializer

    def perform_create(self, serializer):
        serializer.save()  # create() sets agent + reference automatically


class AdminManualQuoteViewSet(mixins.ListModelMixin,
                              mixins.RetrieveModelMixin,
                              mixins.UpdateModelMixin,
                              viewsets.GenericViewSet):
    """Admin endpoints: list, retrieve, partial update (status/premium)."""
    serializer_class = serializers.ManualQuoteSerializer
    permission_classes = [IsStaffOrAdmin]
    lookup_field = 'reference'

    def get_queryset(self):
        qs = models.ManualQuote.objects.all()
        line_key = self.request.query_params.get('line_key')
        status_param = self.request.query_params.get('status')
        agent_code = self.request.query_params.get('agent_code')
        if line_key:
            qs = qs.filter(line_key__iexact=line_key)
        if status_param:
            qs = qs.filter(status=status_param)
        if agent_code:
            qs = qs.filter(agent__staff_user_profile__agent_code=agent_code)
        return qs

    def get_serializer_class(self):
        if self.action in ['partial_update', 'update']:
            return serializers.ManualQuoteAdminUpdateSerializer
        return serializers.ManualQuoteSerializer

    def partial_update(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        # Simple guard: computed_premium requires status COMPLETED
        new_status = serializer.validated_data.get('status')
        if 'computed_premium' in serializer.validated_data and new_status != 'COMPLETED' and instance.status != 'COMPLETED':
            return Response({'detail': 'computed_premium can only be set when status is COMPLETED'}, status=status.HTTP_400_BAD_REQUEST)
        serializer.save()
        return Response(serializers.ManualQuoteSerializer(instance).data)
