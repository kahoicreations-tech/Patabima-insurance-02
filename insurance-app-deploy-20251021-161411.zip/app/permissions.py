"""
Custom permission classes for PataBima API endpoints.

These permissions provide role-based access control for different user types:
- Admin users (is_admin=True)
- Staff users (is_staff=True)
- Agents (users with StaffUserProfile)
- Customers (regular users)
"""

from rest_framework import permissions


class IsStaffOrAdmin(permissions.BasePermission):
    """
    Custom permission to only allow staff or admin users.
    Used for admin-only campaign management endpoints and other staff features.
    
    Returns True if:
    - User is authenticated AND
    - User is staff (is_staff=True) OR admin (is_admin=True)
    """
    def has_permission(self, request, view):
        return bool(
            request.user and 
            request.user.is_authenticated and 
            (request.user.is_staff or request.user.is_admin)
        )


class IsAgent(permissions.BasePermission):
    """
    Custom permission to only allow agent users.
    Agents are users with an associated StaffUserProfile.
    
    Returns True if:
    - User is authenticated AND
    - User has a staff_user_profile (agent profile exists)
    """
    def has_permission(self, request, view):
        return bool(
            request.user and 
            request.user.is_authenticated and 
            hasattr(request.user, 'staff_user_profile') and
            request.user.staff_user_profile is not None
        )


class IsAgentOrAdmin(permissions.BasePermission):
    """
    Allow agents and admin users.
    Combines agent profile check with admin/staff status.
    
    Returns True if:
    - User is authenticated AND
    - (User is admin OR User is staff OR User has agent profile)
    """
    def has_permission(self, request, view):
        return bool(
            request.user and 
            request.user.is_authenticated and 
            (request.user.is_admin or 
             request.user.is_staff or
             (hasattr(request.user, 'staff_user_profile') and 
              request.user.staff_user_profile is not None))
        )
